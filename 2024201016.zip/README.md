Assignment 1 
-Assumptions made: 
	1. The files given as an input are assumed to be in the same directory as of the code.
	2. Code prints the output directly to the console.
	3. Default delimiter is " " unless stated using -F.
Q1
	1. Uses the awk command and its property to divide the data into columns given a delimiter to match the string given.
Q2
	1. Uses the property of awk that allows to store data into variable and update it.


